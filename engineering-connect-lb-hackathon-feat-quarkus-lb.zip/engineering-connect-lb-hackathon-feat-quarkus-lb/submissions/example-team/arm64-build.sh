#!/bin/bash

podman build . --arch arm64 -t example-team:latest
