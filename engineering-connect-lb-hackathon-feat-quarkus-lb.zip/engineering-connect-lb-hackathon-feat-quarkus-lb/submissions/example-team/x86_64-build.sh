#!/bin/bash

podman build . --arch amd64 -t example-team:latest
